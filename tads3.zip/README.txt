TADS 3 for MS-DOS - djgpp 32-bit version

Copyright (c) 1997, 2003 Michael J. Roberts.
Please see the accompanying file "license.txt" for license information.

This is the djgpp version of TADS 3.  djgpp is a version of the Gnu
C++ compiler that produces 32-bit executables that run under MS-DOS on
PC's with 386 and later processors.

This version will NOT run on 8086-based or 80286-based PC's.  You CAN
use this version in a DOS box on 32-bit versions of Windows (95, NT,
or later), but note that you'd probably be better off using the native
Windows version of TADS if you're a Windows user.


About djgpp
-----------

This version of TADS was created using djgpp, a gnu C/C++ compiler for
creating MSDOS-compatible 32-bit programs.  Djgpp is free software.
You can find more information about djgpp, including details on how
you can get your own copy (including source code), at
http://www.delorie.com/djgpp/.

The executables in this distribution include an integrated DOS
extender that allows the programs to run in 32-bit protected mode on
plain DOS.  The extender is a djgpp add-on called CWSDPMI, and you can
find more information about it (and you can get your own copy,
including source code) at http://clio.rice.edu/cwsdpmi/.  The DOS
extender should be fully automatic, so you shouldn't even notice it.

